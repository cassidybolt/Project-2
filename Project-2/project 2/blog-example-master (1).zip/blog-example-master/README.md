# This is my Blog Post
------

### Art Piece 1
![Casey Reas](images/reas.jpg?raw=true "Casey Reas")
This is the first art piece that I like. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur sed quos hic tenetur. Ad ducimus laborum, aut vel sunt placeat, illum perspiciatis ratione et quasi repellat, pariatur cupiditate reprehenderit dolores.

Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur sed quos hic tenetur. Ad ducimus laborum, aut vel sunt placeat, illum perspiciatis ratione et quasi repellat, pariatur cupiditate reprehenderit dolores.
Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur sed quos hic tenetur. Ad ducimus laborum, aut vel sunt placeat, illum perspiciatis ratione et quasi repellat, pariatur cupiditate reprehenderit dolores.

[Here's a link to the piece](http://reas.com/knbc/)


### Art Piece 2

![Jonathan Monaghan](images/monaghan.png?raw=true "Jonathan Monaghan")
This is **another art piece** that I like. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur sed quos hic tenetur. Ad ducimus laborum, aut vel sunt placeat, illum perspiciatis ratione et quasi repellat, pariatur cupiditate reprehenderit dolores.

Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur sed quos hic tenetur. Ad ducimus laborum, aut vel sunt placeat, illum perspiciatis ratione et quasi repellat, pariatur cupiditate reprehenderit dolores.

[Here's a link to the piece](https://vimeo.com/121033081)

### Art Piece 3

![Rafael Lozano-Hemmer](images/hemmer.png?raw=true "Rafael Lozano-Hemmer")
This is **an optional third art piece** that I like. Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur sed quos hic tenetur. Ad ducimus laborum, aut vel sunt placeat, illum perspiciatis ratione et quasi repellat, pariatur cupiditate reprehenderit dolores.

Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur sed quos hic tenetur. Ad ducimus laborum, aut vel sunt placeat, illum perspiciatis ratione et quasi repellat, pariatur cupiditate reprehenderit dolores.

[Here's a link to the piece](http://www.bitforms.com/lozano-hemmer/bilateral-time-slicer)


